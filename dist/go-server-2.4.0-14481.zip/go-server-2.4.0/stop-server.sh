#!/bin/bash

if [ -f /etc/default/go-server ]; then
    . /etc/default/go-server
fi

CWD=`dirname "$0"`
SERVER_DIR=`(cd "$CWD" && pwd)`

[ ! -z $SERVER_MEM ] || SERVER_MEM="512m"
[ ! -z $SERVER_MAX_MEM ] || SERVER_MAX_MEM="1024m"
[ ! -z "$JAVA_HOME" ] || JAVA_HOME="/usr"
[ ! -z $GO_SERVER_PORT ] || GO_SERVER_PORT="8153"
[ ! -z $GO_SERVER_SSL_PORT ] || GO_SERVER_SSL_PORT="8154"
[ ! -z "$SERVER_WORK_DIR" ] || SERVER_WORK_DIR="$SERVER_DIR"

if [ "$PID_FILE" ]; then
    echo "Overriding PID_FILE with $PID_FILE"
elif [ -d /var/run/go-server ]; then
    PID_FILE=/var/run/go-server/go-server.pid
else
    PID_FILE="$SERVER_DIR/go-server.pid"
fi

cat $PID_FILE | xargs kill
